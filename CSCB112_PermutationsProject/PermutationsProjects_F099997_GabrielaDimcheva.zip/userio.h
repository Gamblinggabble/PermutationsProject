#ifndef USER_IO_H
#define USER_IO_H

int printMenu();
int menu(int**, const int, int&, int);

#endif
